class A{
    public:
     int msi_publicLiczba;
     
     int pokazLiczbe(){
        std::cout << msi_publicLiczba;
     }

     void przypiszLiczbe(){
        
     }

     protected:
     int mi_protLiczba;

     private:
     int mi_privLiczba;

     
};

class B{
    public:
    
};