//Agregacja

class A {
public:
	void fA() {}
};
	
class B {
public:
	void fB() {}
private: 
	A* pa;
};	

main(){}

//Kompozycja

class Punkt() {};

class Kolo() {
private:
	double PromienKola;
	Punkt SrodekKola;
public:
	void WstawSrodek() {}
};	

void main(){}
	
